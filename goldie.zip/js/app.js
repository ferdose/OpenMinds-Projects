
window.addEventListener('DOMContentLoaded', function() {

  var data =[]; var prices = [];
  var x = []; var y=[];
  selection_metal.addEventListener("change",function(){
    var option = document.getElementById("selection_metal").value;
    if(option == "gold")
           document.body.style.backgroundColor = "gold";
    else if(option == "silver")
           document.body.style.backgroundColor = "silver";
    else if (option == "copper")
          document.body.style.backgroundColor = "copper";

    
  });
  get_live_price.addEventListener("click",function(){
    var option = document.getElementById("selection_metal").value;
    var url_load = "";
    var grams="";
    console.log(option);
    if(option == "gold"){
      url_load = "http://www.quandl.com/api/v1/datasets/CHRIS/MCX_GC1.json?auth_token=bVaeLgsvxEp9Fakb-33G"
      grams = "10gm";
    }
    else if (option == "silver"){
      url_load = "http://www.quandl.com/api/v1/datasets/CHRIS/MCX_SI1.json?auth_token=bVaeLgsvxEp9Fakb-33G"
      grams = "1kg";
    }
    else if (option == "copper"){
      url_load = "http://www.quandl.com/api/v1/datasets/CHRIS/MCX_CU1.json?auth_token=bVaeLgsvxEp9Fakb-33G"
      grams = "1kg" ;
    }
    console.log(url_load);
    $.ajax({
       url : url_load,
       xhr: function() {
       return new window.XMLHttpRequest( {
        mozSystem: true
         } );
      },
      success: function(response){
        window.response = JSON.parse(response);
        console.log(window.response.data[0]);
        console.log(window.response.data[0][4]);
        document.getElementById("metal_price").innerHTML = "<br>The Price is: Rs.<b>"+window.response.data[0][4]+"</b>/"+grams+"<br>Date:"+window.response.data[0][0]+"<br>";
        for(var i=0;i<30;i++){
          var date = new Date(window.response.data[i][0]);
          var price = window.response.data[i][4];
                  
          data.push(date);
          prices.push(price);
          
        }
       var pass = [
         {
           x : data,
           y : price,
           type: "scatter"
         }
       ]
      }
      });
  });
   
 /* show_chart.addEventListener("click",function(){
     var option = document.getElementById("selection_metal").value;
    var url_load = "";
     if(option == "gold"){
      url_load = "http://www.quandl.com/api/v1/datasets/CHRIS/MCX_GC1.png?auth_token=bVaeLgsvxEp9Fakb-33G"
      
    }
    else if (option == "silver"){
      url_load = "http://www.quandl.com/api/v1/datasets/CHRIS/MCX_SI1.png?auth_token=bVaeLgsvxEp9Fakb-33G"
      
    }
    else if (option == "copper"){
      url_load = "http://www.quandl.com/api/v1/datasets/CHRIS/MCX_CU1.png?auth_token=bVaeLgsvxEp9Fakb-33G"
     }
    
    document.getElementById("display_chart").innerHTML = "<img src="+ "\""+url_load+"\" style=\"width:100%;height:60%;\"></img>";

});*/
  
  show_chart.addEventListener("click",function(){
    var myData = new Array([10, 2], [15, 0], [18, 3], [19, 6], [20, 8.5], [25, 10], [30, 9], [35, 8], [40, 5], [45, 6], [50, 2.5]);
var myChart = new JSChart('chartid', 'line');
myChart.setDataArray(myData);
myChart.setLineColor('#8D9386');
myChart.setLineWidth(4);
myChart.setTitleColor('#7D7D7D');
myChart.setAxisColor('#9F0505');
myChart.setGridColor('#a4a4a4');
myChart.setAxisValuesColor('#333639');
myChart.setAxisNameColor('#333639');
myChart.setTextPaddingLeft(0);
myChart.draw();
           
  });
  
});